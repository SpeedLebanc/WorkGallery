package com.example.workgallery

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.IntentCompat
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.FileOutputStream

// 处理从手机原生相册“分享/移动”过来的文件
fun handleSharedFiles(context: Context, intent: Intent?) {
    if (intent == null) return
    val receiveDir = File(context.getExternalFilesDir(null), "WorkAlbums/SystemGallery")
    if (!receiveDir.exists()) receiveDir.mkdirs()

    try {
        if (intent.action == Intent.ACTION_SEND) {
            val uri = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            uri?.let { saveUriToFile(context, it, receiveDir) }
        } else if (intent.action == Intent.ACTION_SEND_MULTIPLE) {
            val uris = IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)
            uris?.forEach { uri -> saveUriToFile(context, uri, receiveDir) }
        }
    } catch (e: Exception) { e.printStackTrace() }
}

private fun saveUriToFile(context: Context, uri: Uri, targetDir: File) {
    val extension = context.contentResolver.getType(uri)?.split("/")?.last() ?: "jpg"
    val destFile = File(targetDir, "Received_${System.currentTimeMillis()}.$extension")
    context.contentResolver.openInputStream(uri)?.use { input ->
        FileOutputStream(destFile).use { output -> input.copyTo(output) }
    }
}

// 移动文件到系统相册
fun moveFilesToSystemGallery(context: Context, files: Set<File>) {
    files.forEach { file ->
        val mimeType = if (file.extension == "mp4") "video/mp4" else "image/jpeg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/WorkGallery")
        }
        val collection = if (mimeType.startsWith("video")) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        context.contentResolver.insert(collection, values)?.let { dest ->
            context.contentResolver.openOutputStream(dest)?.use { out -> file.inputStream().copyTo(out) }
            file.delete()
        }
    }
}

// 移动文件到任意文件夹 (SAF)
fun moveFilesToSafFolder(context: Context, files: Set<File>, treeUri: Uri) {
    val documentTree = DocumentFile.fromTreeUri(context, treeUri) ?: return
    files.forEach { file ->
        val mimeType = if (file.extension == "mp4") "video/mp4" else "image/jpeg"
        val newDoc = documentTree.createFile(mimeType, file.name)
        newDoc?.uri?.let { destUri ->
            context.contentResolver.openOutputStream(destUri)?.use { out -> file.inputStream().copyTo(out) }
            file.delete()
        }
    }
}

// 获取视频缩略图
fun getVideoThumbnail(path: String): Bitmap? {
    val retriever = MediaMetadataRetriever()
    return try {
        retriever.setDataSource(path)
        retriever.getFrameAtTime(1000000)
    } catch (e: Exception) { null } finally { retriever.release() }
}