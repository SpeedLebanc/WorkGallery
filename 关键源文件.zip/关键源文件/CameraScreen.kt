package com.example.workgallery

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

@SuppressLint("ClickableViewAccessibility")
@Composable
fun CameraScreen(
    targetDirectory: File,
    onCloseCamera: () -> Unit,
    onMediaCaptured: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // 初始化相机资源 (仅在此界面存在时)
    val imageCapture = remember { ImageCapture.Builder().build() }
    val recorder = remember { Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HIGHEST)).build() }
    val videoCapture = remember { VideoCapture.withOutput(recorder) }

    var camera by remember { mutableStateOf<Camera?>(null) }
    var currentRecording by remember { mutableStateOf<Recording?>(null) }
    var recordingSeconds by remember { mutableIntStateOf(0) }

    // 录制计时器
    LaunchedEffect(currentRecording) {
        if (currentRecording != null) {
            recordingSeconds = 0
            while (true) {
                kotlinx.coroutines.delay(1000L)
                recordingSeconds++
            }
        } else {
            recordingSeconds = 0
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // 相机预览视图
        AndroidView(
            modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                detectTransformGestures { _, _, zoom, _ ->
                    camera?.let {
                        val currentZoom = it.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                        it.cameraControl.setZoomRatio(currentZoom * zoom)
                    }
                }
            },
            factory = { ctx ->
                val previewView = PreviewView(ctx)
                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                    try {
                        cameraProvider.unbindAll()
                        camera = cameraProvider.bindToLifecycle(
                            lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture, videoCapture
                        )
                    } catch (exc: Exception) { println("Camera error: ${exc.message}") }
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            }
        )

        // 录制时间显示 (带红点闪烁)
        if (currentRecording != null) {
            val formattedTime = String.format(Locale.getDefault(), "%02d:%02d", recordingSeconds / 60, recordingSeconds % 60)
            Box(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 48.dp)
                    .background(Color.Black.copy(0.6f), MaterialTheme.shapes.large).padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (recordingSeconds % 2 == 0) {
                        Box(modifier = Modifier.size(10.dp).background(Color.Red, androidx.compose.foundation.shape.CircleShape))
                    } else { Spacer(modifier = Modifier.size(10.dp)) }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = formattedTime, color = Color.White, style = MaterialTheme.typography.titleMedium)
                }
            }
        }

        // 底部控制按钮
        Row(
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FloatingActionButton(onClick = onCloseCamera) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(32.dp))
            LargeFloatingActionButton(onClick = { takePhoto(context, imageCapture, targetDirectory, onMediaCaptured) }) {
                Icon(Icons.Default.CameraAlt, contentDescription = "Photo", modifier = Modifier.size(36.dp))
            }
            Spacer(modifier = Modifier.width(32.dp))
            FloatingActionButton(
                onClick = {
                    if (currentRecording != null) {
                        currentRecording?.stop()
                        currentRecording = null
                        onMediaCaptured()
                    } else {
                        currentRecording = captureVideo(context, videoCapture, targetDirectory)
                    }
                }
            ) {
                Icon(Icons.Default.Videocam, contentDescription = "Video", tint = if (currentRecording != null) Color.Red else Color.White)
            }
        }
    }
}

private fun takePhoto(context: Context, imageCapture: ImageCapture, targetDirectory: File, onComplete: () -> Unit) {
    val file = File(targetDirectory, SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA).format(System.currentTimeMillis()) + ".jpg")
    imageCapture.takePicture(
        ImageCapture.OutputFileOptions.Builder(file).build(),
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                Toast.makeText(context, "Photo Saved!", Toast.LENGTH_SHORT).show()
                onComplete()
            }
            override fun onError(exc: ImageCaptureException) { Toast.makeText(context, "Failed!", Toast.LENGTH_SHORT).show() }
        }
    )
}

private fun captureVideo(context: Context, videoCapture: VideoCapture<Recorder>, targetDirectory: File): Recording {
    val file = File(targetDirectory, SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA).format(System.currentTimeMillis()) + ".mp4")
    val pendingRecording = videoCapture.output.prepareRecording(context, FileOutputOptions.Builder(file).build())
    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
        pendingRecording.withAudioEnabled()
    }
    return pendingRecording.start(ContextCompat.getMainExecutor(context)) { event ->
        if (event is VideoRecordEvent.Finalize && !event.hasError()) {
            Toast.makeText(context, "Video Saved!", Toast.LENGTH_SHORT).show()
        }
    }
}